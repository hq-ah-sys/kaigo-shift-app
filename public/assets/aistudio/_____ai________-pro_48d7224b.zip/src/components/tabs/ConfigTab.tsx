import React, { useState } from 'react';
import { AppState, AIConfig } from '../../types';
import { getInitialDemoState } from '../../constants';
import { testAIServerConnection } from '../../utils/geminiAI';
import { Settings, Key, Sparkles, Download, Upload, RotateCcw, CheckCircle2, AlertTriangle, Eye, EyeOff, Server } from 'lucide-react';

interface Props {
  state: AppState;
  onUpdateState: (updater: (prev: AppState) => AppState) => void;
}

export const ConfigTab: React.FC<Props> = ({ state, onUpdateState }) => {
  const [provider, setProvider] = useState<'gemini' | 'claude'>(state.aiConfig.provider || 'gemini');
  const [geminiKey, setGeminiKey] = useState(state.aiConfig.geminiKey || '');
  const [geminiModel, setGeminiModel] = useState(state.aiConfig.geminiModel || 'gemini-3.8-flash');
  const [claudeKey, setClaudeKey] = useState(state.aiConfig.claudeKey || '');
  const [claudeModel, setClaudeModel] = useState(state.aiConfig.claudeModel || 'claude-3-7-sonnet-20250219');

  const [showKey, setShowKey] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; msg: string } | null>(null);
  const [testing, setTesting] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSave = () => {
    onUpdateState((prev) => ({
      ...prev,
      aiConfig: {
        provider,
        geminiKey: geminiKey.trim(),
        geminiModel,
        claudeKey: claudeKey.trim(),
        claudeModel,
      },
    }));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);

    try {
      const res = await testAIServerConnection();
      setTestResult({
        success: res.success,
        msg: res.message,
      });
    } catch (err: any) {
      setTestResult({
        success: false,
        msg: `接続失敗: ${err.message}`,
      });
    } finally {
      setTesting(false);
    }
  };

  const handleExportBackup = () => {
    const jsonStr = JSON.stringify(state, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `介護シフトPro_バックアップ_${state.year}年${state.month}月.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        if (!parsed.facilities || !parsed.staff) {
          throw new Error('データ形式が不正です（必要なキーがありません）');
        }
        if (confirm('現在のデータをバックアップデータで上書きしますか？')) {
          onUpdateState(() => parsed);
          alert('✅ バックアップデータを復元しました');
        }
      } catch (err: any) {
        alert(`復元に失敗しました: ${err.message}`);
      }
      e.target.value = '';
    };
    reader.readAsText(file, 'UTF-8');
  };

  const handleResetToDemo = () => {
    if (confirm('すべての変更を破棄し、初期デモデータに戻しますか？')) {
      const demo = getInitialDemoState();
      onUpdateState(() => demo);
      alert('初期デモデータに戻しました');
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Top Card */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-xs p-5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200 text-purple-600">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-900">システム設定 & APIキー管理</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Gemini AIの接続キー設定、データの全体バックアップ・復元、初期データリセットを行います
            </p>
          </div>
        </div>
      </div>

      {/* AI Provider & API Key Settings */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-xs p-6 space-y-5">
        <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
          <Key className="w-5 h-5 text-blue-600" />
          <h3 className="font-bold text-gray-900 text-base">Gemini AI API 設定</h3>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl space-y-2 text-xs text-blue-900">
            <div className="flex items-center gap-2 font-bold text-blue-900">
              <Server className="w-4.5 h-4.5 text-blue-600 shrink-0" />
              <span>サーバーサイド Gemini API 統合稼働中</span>
            </div>
            <p className="text-gray-600 leading-relaxed">
              APIキーはサーバー側環境（Settings &gt; Secrets）にて安全に管理され、/api/ai/* エンドポイントを経由して実行されます。クライアント側にキーを入力する必要はありません。
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
              使用モデル
            </label>
            <select
              value={geminiModel}
              onChange={(e) => setGeminiModel(e.target.value)}
              className="w-full max-w-sm px-3.5 py-2 rounded-xl border border-gray-300 bg-white text-xs font-bold text-gray-700 focus:border-blue-600 outline-hidden"
            >
              <option value="gemini-3.8-flash">gemini-3.8-flash (推奨・高速高精度)</option>
              <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (軽量)</option>
            </select>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={handleSave}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition cursor-pointer"
            >
              設定を保存する
            </button>

            <button
              onClick={handleTestConnection}
              disabled={testing}
              className="px-4 py-2.5 rounded-xl border border-purple-300 bg-purple-50 hover:bg-purple-100 text-purple-800 font-bold text-xs transition cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span>{testing ? '接続テスト中...' : '🔌 API接続テスト'}</span>
            </button>

            {saveSuccess && (
              <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4" />
                <span>設定を保存しました</span>
              </span>
            )}
          </div>

          {testResult && (
            <div
              className={`p-3.5 rounded-xl border text-xs font-medium flex items-center gap-2 ${
                testResult.success
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-red-50 border-red-200 text-red-900'
              }`}
            >
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
              )}
              <span>{testResult.msg}</span>
            </div>
          )}
        </div>
      </div>

      {/* Backup and Restore */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-xs p-6 space-y-4">
        <h3 className="font-bold text-gray-900 text-base">💾 データのバックアップと初期化</h3>
        <p className="text-xs text-gray-500">
          事業所、職員マスタ、シフトパターン、希望入力、シフト実績などすべてのデータをJSONファイルで保管・復元できます。
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <button
            onClick={handleExportBackup}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gray-900 hover:bg-black text-white font-bold text-xs shadow-xs transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>全データ バックアップ保存 (.json)</span>
          </button>

          <label className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-bold text-xs shadow-xs transition cursor-pointer">
            <Upload className="w-4 h-4" />
            <span>バックアップ復元</span>
            <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
          </label>

          <button
            onClick={handleResetToDemo}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold text-xs transition cursor-pointer ml-auto"
          >
            <RotateCcw className="w-4 h-4" />
            <span>初期デモデータに戻す</span>
          </button>
        </div>
      </div>
    </div>
  );
};
