import { AppState, ParsedRule } from '../types';
import { daysInMonth } from './shiftEngine';
import { computeStaffSummaries, runFacilityChecks } from './complianceEngine';

// Local rule parser fallback in case network is unavailable
export function parseInstructionLocally(text: string, state: AppState): ParsedRule[] {
  const rules: ParsedRule[] = [];
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);

  lines.forEach((line, index) => {
    // Find staff mentioned in the line
    const matchedStaff = state.staff.find((s) => line.includes(s.name));

    // Case 1: Deduct hours (e.g. 2時間を管理業務に使う, 3時間は労働時間から除いて)
    const hoursMatch = line.match(/(\d+)\s*(?:時間|h).*(?:除いて|管理業務|実働|引いて|マイナス)/);
    const dateMatch = line.match(/(\d{1,2})\s*日/g);

    if (hoursMatch && matchedStaff) {
      const deduct = parseInt(hoursMatch[1], 10);
      let targetDates: number[] | undefined = undefined;
      if (dateMatch) {
        targetDates = dateMatch.map((dm) => parseInt(dm.replace('日', ''), 10));
      }
      rules.push({
        id: `rule-${Date.now()}-${index}`,
        text: line,
        staffName: matchedStaff.name,
        staffId: matchedStaff.id,
        ruleType: 'deduct_hours',
        hours: deduct,
        dates: targetDates,
      });
      return;
    }

    // Case 2: Max days per week (e.g. 週3日以内に抑えて)
    const maxDaysMatch = line.match(/週\s*(\d+)\s*日/);
    if (maxDaysMatch && matchedStaff) {
      const maxD = parseInt(maxDaysMatch[1], 10);
      rules.push({
        id: `rule-${Date.now()}-${index}`,
        text: line,
        staffName: matchedStaff.name,
        staffId: matchedStaff.id,
        ruleType: 'max_days',
        maxDays: maxD,
      });
      return;
    }

    // Case 3: Leave on specific dates
    if (dateMatch && matchedStaff && (line.includes('休') || line.includes('不在') || line.includes('有休'))) {
      const dates = dateMatch.map((dm) => parseInt(dm.replace('日', ''), 10));
      rules.push({
        id: `rule-${Date.now()}-${index}`,
        text: line,
        staffName: matchedStaff.name,
        staffId: matchedStaff.id,
        ruleType: 'specific_date_leave',
        dates,
      });
      return;
    }

    // Default general note rule
    rules.push({
      id: `rule-${Date.now()}-${index}`,
      text: line,
      staffName: matchedStaff?.name,
      staffId: matchedStaff?.id,
      ruleType: 'deduct_hours',
      hours: 0,
    });
  });

  return rules;
}

export async function interpretInstructionsWithAI(
  text: string,
  state: AppState
): Promise<{ rules: ParsedRule[]; rawAnalysis: string }> {
  try {
    const resp = await fetch('/api/ai/interpret', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        instructionText: text,
        staffList: state.staff.map((s) => ({ id: s.id, name: s.name })),
      }),
    });

    if (!resp.ok) {
      const errData = await resp.json().catch(() => ({}));
      throw new Error(errData.error || `Server responded with status ${resp.status}`);
    }

    const data = await resp.json();
    const mappedRules: ParsedRule[] = (data.rules || []).map((r: any, idx: number) => ({
      id: `ai-rule-${Date.now()}-${idx}`,
      text: r.text || text,
      staffName: r.staffName,
      staffId: r.staffId,
      ruleType: r.ruleType || 'deduct_hours',
      hours: r.hours,
      maxDays: r.maxDays,
      dates: r.dates,
    }));

    return {
      rules: mappedRules.length > 0 ? mappedRules : parseInstructionLocally(text, state),
      rawAnalysis: data.summary || 'AI解析が完了しました（サーバーサイド Gemini 3.8 Flash）',
    };
  } catch (err: any) {
    console.warn('Server-side AI parsing fallback to local parser:', err);
    const localRules = parseInstructionLocally(text, state);
    return {
      rules: localRules,
      rawAnalysis: `【解析完了（ローカルパーサー）】${err.message ? ` (サーバー連携: ${err.message})` : ''}`,
    };
  }
}

export async function runAIComplianceAudit(state: AppState): Promise<string> {
  const { year, month, facility, staff } = state;
  const days = daysInMonth(year, month);
  const staffSummaries = computeStaffSummaries(state);
  const facilityChecks = runFacilityChecks(state);

  const payload = {
    month: `${year}年${month}月 (${days}日間)`,
    facility: {
      name: facility.name,
      typeId: facility.typeId,
      users: facility.users,
      staffCount: staff.length,
    },
    facilityChecks,
    staffSummaries: staffSummaries.map((s) => ({
      name: s.name,
      role: s.role,
      workDays: s.workDays,
      totalHours: s.totalNetHours,
      avgWeeklyHours: s.avgWeeklyHours,
      fte: s.fte,
      over36: s.over36,
      maxConsecutive: s.maxConsecutive,
    })),
  };

  try {
    const resp = await fetch('/api/ai/audit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ payload }),
    });

    if (!resp.ok) {
      const errData = await resp.json().catch(() => ({}));
      throw new Error(errData.error || `Server responded with status ${resp.status}`);
    }

    const data = await resp.json();
    return data.report || 'AI診断レポートの生成が完了しました。';
  } catch (err: any) {
    console.warn('Server-side Gemini audit failed, fallback to local rule audit:', err);
    // Intelligent local fallback report
    const failedChecks = facilityChecks.flatMap((f) => f.checks.filter((c) => !c.passed));
    const over36Staff = staffSummaries.filter((s) => s.over36);
    const highConsecStaff = staffSummaries.filter((s) => s.maxConsecutive >= 6);

    let report = `### 📋 介護シフト・コンプライアンス自動診断結果 (${year}年${month}月)\n\n`;
    report += `**総合評価:** ${failedChecks.length === 0 && over36Staff.length === 0 ? '✅ 概ね良好（法令・人員基準適合）' : '⚠️ 是正推奨（一部要確認事項あり）'}\n\n`;

    report += `#### 1. 人員配置基準チェック\n`;
    if (failedChecks.length === 0) {
      report += `- ${facility.name} において法令上の配置基準をすべてクリアしています。\n`;
    } else {
      failedChecks.forEach((c) => {
        report += `- ❌ **${c.label}**: 要件「${c.req}」に対し実績「${c.actual}」と未達です。\n`;
      });
    }

    report += `\n#### 2. 労働基準法・36協定・連続勤務\n`;
    if (over36Staff.length === 0) {
      report += `- 週40時間超過職員はいません。\n`;
    } else {
      over36Staff.forEach((s) => {
        report += `- ⚠️ **${s.name}**: 週平均実労働${s.avgWeeklyHours.toFixed(1)}h（法定週40h超過の恐れがあります）。\n`;
      });
    }

    if (highConsecStaff.length > 0) {
      highConsecStaff.forEach((s) => {
        report += `- ⚠️ **${s.name}**: 最大${s.maxConsecutive}連勤が設定されています。5連勤以下への分散を推奨します。\n`;
      });
    } else {
      report += `- 6連勤以上の過度な連続勤務はありません。\n`;
    }

    report += `\n#### 3. 改善アドバイス\n`;
    report += `1. 夜勤明けの翌日は原則公休とし、十分な休息時間を確保してください。\n`;
    report += `2. 週40時間を超える恐れのある非常勤・常勤職員の勤務シフトを再配分してください。\n`;
    report += `3. 有給休暇の計画的付与（年5日取得義務）を月次で順次進めてください。\n`;

    return report;
  }
}

export async function testAIServerConnection(): Promise<{ success: boolean; message: string }> {
  try {
    const resp = await fetch('/api/ai/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    const data = await resp.json();
    if (!resp.ok) {
      return { success: false, message: data.message || `エラー: HTTP ${resp.status}` };
    }
    return { success: data.success, message: data.message };
  } catch (err: any) {
    return { success: false, message: `サーバー接続エラー: ${err.message}` };
  }
}
