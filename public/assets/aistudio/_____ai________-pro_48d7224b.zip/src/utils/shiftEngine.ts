import { AppState, Facility, ShiftPattern, Staff, ParsedRule } from '../types';
import { FACILITY_TYPES, SPECIAL_SHIFTS, SP_COLOR, SP_TEXT_COLOR, SP_SHORT } from '../constants';

export function daysInMonth(y: number, m: number): number {
  return new Date(y, m, 0).getDate();
}

export function dayOfWeekIdx(y: number, m: number, d: number): number {
  return new Date(y, m - 1, d).getDay();
}

export function dayOfWeekName(y: number, m: number, d: number): string {
  return ['日', '月', '火', '水', '木', '金', '土'][dayOfWeekIdx(y, m, d)];
}

export function dayOfWeekClass(y: number, m: number, d: number): 'sun' | 'sat' | '' {
  const w = dayOfWeekIdx(y, m, d);
  return w === 0 ? 'sun' : w === 6 ? 'sat' : '';
}

export function timeToMinutes(t: string | null | undefined): number {
  if (!t) return 0;
  const parts = t.split(':').map(Number);
  return (parts[0] || 0) * 60 + (parts[1] || 0);
}

export function minutesToTime(m: number): string {
  const h = Math.floor(m / 60) % 24;
  const min = m % 60;
  return `${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}`;
}

export function grossHours(p: ShiftPattern | null | undefined): number {
  if (!p || SPECIAL_SHIFTS.includes(p.key as any)) return 0;
  const s = timeToMinutes(p.start);
  const e = timeToMinutes(p.end);
  return e > s ? (e - s) / 60 : (1440 - s + e) / 60;
}

// 労働基準法（Labor Standards Act）に基づく休憩時間控除
// 6h超え〜8h以下: 45分 (0.75h)
// 8h超え: 1時間 (1.0h)
export function breakTime(gross: number): number {
  if (gross > 8) return 1.0;
  if (gross > 6) return 0.75;
  return 0;
}

export function netHours(p: ShiftPattern | null | undefined): number {
  const g = grossHours(p);
  return Math.max(0, g - breakTime(g));
}

export function isNight(p: ShiftPattern | null | undefined): boolean {
  if (!p || SPECIAL_SHIFTS.includes(p.key as any)) return false;
  const s = timeToMinutes(p.start);
  const e = timeToMinutes(p.end);
  if (e >= s) return false;
  // 夜勤は22:00〜翌05:00を含むパターン
  return s <= 22 * 60 && e >= 5 * 60;
}

export function parseTimeVal(val: string): { start: string; end: string } | null {
  if (!val || !val.startsWith('time:')) return null;
  const t = val.slice(5);
  const [s, e] = t.split('-');
  if (!s || !e) return null;
  return { start: s, end: e };
}

export function getTimeKeyHours(key: string): number {
  const tv = parseTimeVal(key);
  if (!tv) return 0;
  const s = timeToMinutes(tv.start);
  const e = timeToMinutes(tv.end);
  const gross = (e > s ? e - s : 1440 - s + e) / 60;
  return Math.max(0, gross - breakTime(gross));
}

export function isWorkShift(key: string | undefined): boolean {
  if (!key || key === '' || key === '公休' || SPECIAL_SHIFTS.includes(key as any)) return false;
  return true;
}

export function getPatternByKey(
  key: string,
  facilityId: number | null,
  patterns: ShiftPattern[]
): ShiftPattern | undefined {
  if (!key || SPECIAL_SHIFTS.includes(key as any)) return undefined;
  return (
    patterns.find((p) => p.facilityId === facilityId && p.key === key) ||
    patterns.find((p) => p.key === key)
  );
}

export function getStaffDayNetH(
  staffId: number,
  day: number,
  key: string,
  facilityId: number,
  patterns: ShiftPattern[],
  parsedRules: ParsedRule[] = []
): number {
  if (!key || key === '公休' || key === '有休' || key === '希望休' || key === '明け' || key === '他事業所') {
    return 0;
  }
  let baseH = 0;
  if (key.startsWith('time:')) {
    baseH = getTimeKeyHours(key);
  } else {
    const pat = getPatternByKey(key, facilityId, patterns);
    baseH = pat ? netHours(pat) : 0;
  }

  // Check custom rules parsed from instructions
  if (baseH > 0 && parsedRules.length > 0) {
    for (const r of parsedRules) {
      if (r.staffId === staffId || !r.staffId) {
        if (r.ruleType === 'deduct_hours' && r.hours) {
          // If date specific
          if (!r.dates || r.dates.includes(day)) {
            baseH = Math.max(0, baseH - r.hours);
          }
        }
      }
    }
  }

  return baseH;
}

/**
 * 職員の指定職種（デフォルト: 介護職員）に対する有効配置比率（0.0 〜 1.0）を算出します。
 * 
 * 介護保険法・指定基準の必須ルール：
 * 1. 管理者（管理職分）は介護職の人員配置基準から控除（抜く）。
 * 2. 計画作成担当者（計画作成業務分）は介護職の人員配置基準から控除（抜く）。
 * 3. 専従管理者・専従計画作成担当者は、介護職としてカウント不可（0.0）。
 * 4. 同事業所内兼務（例: 管理者4h / 介護職4h）の場合、介護職員として割り当てられた時間割合のみ（例: 4h/8h = 0.5人）を算定し、管理職分・計画作成分は厳密に除外（抜く）。
 */
export function getStaffRoleAllocationRatio(
  staff: Staff,
  targetRoles: string[] = ['介護職員']
): number {
  const staffRoles = Array.isArray(staff.roles) ? staff.roles : [staff.role];

  // 該当する職種を一切担当していない場合（例: 専従管理者、専従計画作成担当者など）
  const matchingRoles = staffRoles.filter((r) => targetRoles.includes(r));
  if (matchingRoles.length === 0) {
    return 0;
  }

  // 単一職種で、かつそれが対象職種の場合（例: 専従の介護職員）
  if (staffRoles.length === 1) {
    return 1.0;
  }

  // 複数職種（兼務）の場合: 1日の時間配分 (roleHours) に基づいて厳密に按分
  if (staff.roleHours && Object.keys(staff.roleHours).length > 0) {
    let targetHours = 0;
    let totalAllocatedHours = 0;

    staffRoles.forEach((r) => {
      const h = staff.roleHours?.[r] ?? (8 / staffRoles.length);
      totalAllocatedHours += h;
      if (targetRoles.includes(r)) {
        targetHours += h;
      }
    });

    if (totalAllocatedHours > 0) {
      return Math.min(1.0, Math.max(0, targetHours / totalAllocatedHours));
    }
  }

  // roleHoursが未指定の兼務の場合: 職種数で均等按分（例: 2職種兼務なら 1/2 = 0.5）
  return matchingRoles.length / staffRoles.length;
}

/**
 * 職員の指定職種（例: 介護職）実働時間（h）を算出
 * 管理者（管理職分）や計画作成担当者（計画作成分）は除外されます。
 */
export function getStaffDayRoleHours(
  staff: Staff,
  day: number,
  key: string,
  facilityId: number,
  patterns: ShiftPattern[],
  parsedRules: ParsedRule[] = [],
  targetRoles: string[] = ['介護職員']
): number {
  const fullDayH = getStaffDayNetH(staff.id, day, key, facilityId, patterns, parsedRules);
  if (fullDayH <= 0) return 0;
  const ratio = getStaffRoleAllocationRatio(staff, targetRoles);
  return fullDayH * ratio;
}

export function calcFTE(totalHours: number, days: number): string {
  const fullTimeMonthly = (40 / 7) * days;
  if (fullTimeMonthly <= 0) return '0.00';
  const fte = totalHours / fullTimeMonthly;
  return Math.min(fte, 1.0).toFixed(2);
}

export function isStaffWorkingOnFacilityDay(
  staff: Staff,
  year: number,
  month: number,
  day: number
): boolean {
  if (!staff.otherFacilityConcurrent) return true;

  const scheduleType = staff.interFacilityScheduleType || 'dow';
  if (scheduleType === 'dow') {
    const dow = dayOfWeekIdx(year, month, day);
    const daysList = staff.interFacilityDays || [0, 1, 2, 3, 4, 5, 6];
    return daysList.includes(dow);
  } else {
    const datesList = staff.interFacilityDates || [];
    return datesList.includes(day);
  }
}

export function isStaffAvailable(
  staff: Staff,
  year: number,
  month: number,
  day: number,
  pattern?: ShiftPattern
): boolean {
  // Check inter-facility concurrent work assignment
  if (!isStaffWorkingOnFacilityDay(staff, year, month, day)) {
    return false;
  }

  const dow = dayOfWeekIdx(year, month, day);
  // Check available days of week
  if (staff.availDays && staff.availDays.length > 0 && !staff.availDays.includes(dow)) {
    return false;
  }
  // Check available time slot
  if (staff.availTimeEnabled && staff.availStart && staff.availEnd && pattern) {
    if (!isNight(pattern)) {
      const avS = timeToMinutes(staff.availStart);
      const avE = timeToMinutes(staff.availEnd);
      const ptS = timeToMinutes(pattern.start);
      const ptE = timeToMinutes(pattern.end);

      // Pattern start time check (allow 60 minutes grace so 08:30 or 09:00 staff can take 09:00 or 08:30 day shift)
      if (ptS < avS - 60) return false;
      if (ptS >= avE) return false;
      // Pattern end time check (allow 120 minutes grace for standard day shift)
      if (ptE > avE + 120) return false;
    }
  }
  return true;
}

export function checkCoverageGaps(facilityId: number, patterns: ShiftPattern[]): Array<{ from: number; to: number }> {
  const pats = patterns.filter((p) => p.facilityId === facilityId);
  if (pats.length === 0) return [];
  const covered = new Array(1440).fill(false);
  pats.forEach((p) => {
    const s = timeToMinutes(p.start);
    const e = timeToMinutes(p.end);
    if (e > s) {
      for (let i = s; i < e; i++) covered[i] = true;
    } else {
      for (let i = s; i < 1440; i++) covered[i] = true;
      for (let i = 0; i < e; i++) covered[i] = true;
    }
  });

  const gaps: Array<{ from: number; to: number }> = [];
  let gapStart: number | null = null;
  for (let i = 0; i < 1440; i++) {
    if (!covered[i] && gapStart === null) gapStart = i;
    if (covered[i] && gapStart !== null) {
      gaps.push({ from: gapStart, to: i });
      gapStart = null;
    }
  }
  if (gapStart !== null) gaps.push({ from: gapStart, to: 1440 });
  return gaps;
}

function getNeededStaff(fc: Facility): number {
  const fcType = FACILITY_TYPES.find((t) => t.id === fc.typeId);
  if (!fcType || !fcType.ratio) return 2;
  return Math.max(2, Math.ceil(fc.users / fcType.ratio));
}

export function generateShifts(state: AppState): Record<number, Record<number, string>> {
  const { year, month, staff, preferences, pairs, shiftPatterns, lockedStaff, parsedRules } = state;
  const days = daysInMonth(year, month);
  const lockedSet = new Set(lockedStaff);
  const newShifts: Record<number, Record<number, string>> = {};

  // Initialize all staff shifts
  staff.forEach((s) => {
    newShifts[s.id] = {};
    if (lockedSet.has(s.id)) {
      for (let d = 1; d <= days; d++) {
        newShifts[s.id][d] = state.shifts[s.id]?.[d] || '公休';
      }
    } else {
      for (let d = 1; d <= days; d++) {
        if (!isStaffWorkingOnFacilityDay(s, year, month, d)) {
          newShifts[s.id][d] = '他事業所';
        } else {
          newShifts[s.id][d] = '公休';
        }
      }
    }
  });

  // Apply user preferences first (希望休, 有休, pre-entered shifts)
  staff.forEach((s) => {
    if (lockedSet.has(s.id)) return;
    const pref = preferences[s.id] || {};
    Object.entries(pref).forEach(([dStr, val]) => {
      const d = parseInt(dStr, 10);
      newShifts[s.id][d] = val;
    });
  });

  // Apply custom parsed rules for leave / days
  if (parsedRules && parsedRules.length > 0) {
    parsedRules.forEach((rule) => {
      if (rule.ruleType === 'specific_date_leave' && rule.staffId && rule.dates) {
        rule.dates.forEach((d) => {
          if (!lockedSet.has(rule.staffId!)) {
            newShifts[rule.staffId!][d] = '公休';
          }
        });
      }
    });
  }

  // Iterate over facilities to generate schedule
  state.facilities.forEach((fc) => {
    const fcType = FACILITY_TYPES.find((t) => t.id === fc.typeId);
    const fcStaff = staff.filter((s) => s.facilityId === fc.id);

    const fcPats = shiftPatterns.filter((p) => p.facilityId === fc.id);
    const dayPats = fcPats.filter((p) => !isNight(p));
    const nightPats = fcPats.filter((p) => isNight(p));
    const useNight = fcType && fcType.nightRequired && nightPats.length > 0;

    if (dayPats.length === 0 && !useNight) return;

    // Monthly hour limits based on contract (e.g. 171.4h for 40h in 30-day month)
    const monthHLimit = (s: Staff) => (s.hours * days) / 7;

    const getMonthH = (s: Staff) => {
      let h = 0;
      for (let i = 1; i <= days; i++) {
        const k = newShifts[s.id][i] || '公休';
        h += getStaffDayNetH(s.id, i, k, fc.id, shiftPatterns, parsedRules);
      }
      return h;
    };

    const getConsecutive = (s: Staff, day: number) => {
      let c = 0;
      for (let i = day - 1; i >= Math.max(1, day - 6); i--) {
        if (isWorkShift(newShifts[s.id][i])) c++;
        else break;
      }
      return c;
    };

    const hasForbiddenConflict = (s: Staff, day: number) => {
      const forb = pairs.filter((p) => p.type === 'forbidden' && (p.a === s.id || p.b === s.id));
      return forb.some((p) => {
        const otherId = p.a === s.id ? p.b : p.a;
        return isWorkShift(newShifts[otherId]?.[day]);
      });
    };

    // 1. Night shift assignment for residential 24h facilities
    if (useNight && nightPats.length > 0) {
      const np = nightPats[0];
      const npH = netHours(np);

      for (let d = 1; d <= days; d++) {
        const alreadyHasNight = fcStaff.some((s) => {
          const k = newShifts[s.id][d];
          return nightPats.some((p) => p.key === k);
        });
        if (alreadyHasNight) continue;

        let eligNight = fcStaff.filter((s) => {
          if (lockedSet.has(s.id)) return false;
          if (newShifts[s.id][d] !== '公休') return false;
          if (!s.night) return false;
          if ((s.mat || 3) < 3) return false;
          if ((preferences[s.id] || {})[d]) return false;
          if (!isStaffAvailable(s, year, month, d, np)) return false;
          if (d + 1 <= days && newShifts[s.id][d + 1] !== '公休' && newShifts[s.id][d + 1] !== '明け') return false;
          if (getMonthH(s) + npH > monthHLimit(s) + 0.1) return false;
          if (getConsecutive(s, d) >= 4) return false;
          if (hasForbiddenConflict(s, d)) return false;
          return true;
        });

        if (eligNight.length > 0) {
          const countNights = (s: Staff) =>
            Object.values(newShifts[s.id]).filter((k) => nightPats.some((p) => p.key === k)).length;

          eligNight.sort((a, b) => {
            if (a.nightOnly && !b.nightOnly) return -1;
            if (!a.nightOnly && b.nightOnly) return 1;
            const nd = countNights(a) - countNights(b);
            if (nd !== 0) return nd;
            return (getMonthH(a) / monthHLimit(a)) - (getMonthH(b) / monthHLimit(b));
          });

          const picked = eligNight[0];
          newShifts[picked.id][d] = np.key;
          if (d + 1 <= days && !lockedSet.has(picked.id)) {
            newShifts[picked.id][d + 1] = '明け';
          }
          if (d + 2 <= days && !lockedSet.has(picked.id) && !preferences[picked.id]?.[d + 2]) {
            newShifts[picked.id][d + 2] = '公休';
          }
        }
      }
    }

    if (dayPats.length === 0) return;

    // Shift patterns
    const stdDayPat = dayPats.find((p) => p.key === '日') || dayPats[0];
    const earlyPat = dayPats.find((p) => p.key === '早' || p.name.includes('早')) || dayPats[0];
    const latePat = dayPats.find((p) => p.key === '遅' || p.name.includes('遅')) || (dayPats.length > 2 ? dayPats[2] : dayPats[dayPats.length - 1]);
    const stdDayH = netHours(stdDayPat);
    const earlyH = netHours(earlyPat);
    const lateH = netHours(latePat);

    // Helper to calculate weekly hours for staff in the 7-day week around a given day
    const getWeeklyH = (s: Staff, day: number) => {
      const dow = dayOfWeekIdx(year, month, day);
      const startD = Math.max(1, day - dow);
      const endD = Math.min(days, day + (6 - dow));
      let h = 0;
      for (let i = startD; i <= endD; i++) {
        const k = newShifts[s.id][i] || '公休';
        h += getStaffDayNetH(s.id, i, k, fc.id, shiftPatterns, parsedRules);
      }
      return h;
    };

    // 2. Schedule Administrative & Plan Creator Roles (管理者・計画作成担当者)
    // Principles:
    // - Primary priority: Assign standard Day Shift on Weekdays (月〜金)
    // - Secondary priority: Allow assignment on Weekends & Holidays (土日祝) if total weekly hours <= 40h (or contracted hours)
    const adminStaff = fcStaff.filter((s) => {
      const roles = Array.isArray(s.roles) ? s.roles : [s.role];
      return roles.includes('管理者') || roles.includes('計画作成担当者');
    });

    adminStaff.forEach((s) => {
      if (lockedSet.has(s.id)) return;

      const matchedDayPat = dayPats.find((p) => isStaffAvailable(s, year, month, 1, p)) || stdDayPat;

      const getAdminShiftKey = (d: number) => {
        if (s.availTimeEnabled && s.availStart && s.availEnd) {
          if (matchedDayPat && isStaffAvailable(s, year, month, d, matchedDayPat)) {
            return matchedDayPat.key;
          }
          return `time:${s.availStart}-${s.availEnd}`;
        }
        return matchedDayPat?.key || stdDayPat?.key || '日';
      };

      const maxWeeklyH = Math.max(40, s.hours || 40);

      // Pass 1: Weekday Day Shift Assignment (月〜金: 平日の日勤帯)
      for (let d = 1; d <= days; d++) {
        if (newShifts[s.id][d] !== '公休') continue;

        const dow = dayOfWeekIdx(year, month, d);
        const isWeekday = dow >= 1 && dow <= 5;
        if (!isWeekday) continue;

        const shiftKey = getAdminShiftKey(d);
        const shiftH = getStaffDayNetH(s.id, d, shiftKey, fc.id, shiftPatterns, parsedRules);

        if (!isStaffAvailable(s, year, month, d, matchedDayPat)) continue;
        if (getConsecutive(s, d) >= 5) continue;
        if (getWeeklyH(s, d) + shiftH > maxWeeklyH + 0.1) continue;
        if (getMonthH(s) + shiftH > monthHLimit(s) + 0.1) continue;
        if (hasForbiddenConflict(s, d)) continue;

        newShifts[s.id][d] = shiftKey;
      }

      // Pass 2: Weekend & Holiday Day Shift Assignment (土日祝: 週40時間を超えない範囲)
      for (let d = 1; d <= days; d++) {
        if (newShifts[s.id][d] !== '公休') continue;

        const dow = dayOfWeekIdx(year, month, d);
        const isWeekend = dow === 0 || dow === 6;
        if (!isWeekend) continue;

        const shiftKey = getAdminShiftKey(d);
        const shiftH = getStaffDayNetH(s.id, d, shiftKey, fc.id, shiftPatterns, parsedRules);

        if (!isStaffAvailable(s, year, month, d, matchedDayPat)) continue;
        if (getConsecutive(s, d) >= 5) continue;
        if (getWeeklyH(s, d) + shiftH > maxWeeklyH + 0.1) continue;
        if (getMonthH(s) + shiftH > monthHLimit(s) + 0.1) continue;
        if (hasForbiddenConflict(s, d)) continue;

        newShifts[s.id][d] = shiftKey;
      }
    });

    // 3. Schedule Part-time / Specialized Availability Staff (山田花子, 小林誠, 伊藤綾乃, etc.)
    // Prioritize scheduling part-time staff on their designated available days/times up to contract limit
    const partTimeStaff = fcStaff.filter((s) => {
      if (adminStaff.some((a) => a.id === s.id)) return false;
      return s.type !== '常勤' || s.hours < 35;
    });

    partTimeStaff.forEach((s) => {
      if (lockedSet.has(s.id)) return;
      for (let d = 1; d <= days; d++) {
        if (newShifts[s.id][d] !== '公休') continue;

        // Facility open check for day service
        if (fc.typeId === 'dayservice' && fc.bizDays && fc.bizDays.length > 0) {
          const dow = dayOfWeekIdx(year, month, d);
          if (!fc.bizDays.includes(dow)) continue;
        }

        // Find matching day pattern for staff
        const pat = dayPats.find((p) => isStaffAvailable(s, year, month, d, p)) || stdDayPat;
        if (!isStaffAvailable(s, year, month, d, pat)) continue;

        const patH = netHours(pat);
        if (getConsecutive(s, d) >= 5) continue;
        if (getMonthH(s) + patH > monthHLimit(s) + 0.1) continue;
        if (hasForbiddenConflict(s, d)) continue;

        newShifts[s.id][d] = pat.key;
      }
    });

    // 4. Core Early ('早') and Late ('遅') Coverage Prioritized by Scarcity (Sundays -> Saturdays -> Weekdays)
    // Scheduling scarce weekend days first prevents full-time staff from burning their hours on weekdays
    const careStaff = fcStaff.filter((s) => !adminStaff.some((a) => a.id === s.id));
    const allDaysSortedByScarcity = Array.from({ length: days }, (_, i) => i + 1).sort((a, b) => {
      const dowA = dayOfWeekIdx(year, month, a);
      const dowB = dayOfWeekIdx(year, month, b);
      const score = (d: number) => (d === 0 ? 0 : d === 6 ? 1 : 2);
      return score(dowA) - score(dowB);
    });

    allDaysSortedByScarcity.forEach((d) => {
      if (fc.typeId === 'dayservice' && fc.bizDays && fc.bizDays.length > 0) {
        const dow = dayOfWeekIdx(year, month, d);
        if (!fc.bizDays.includes(dow)) return;
      }

      // Early shift
      const hasEarly = careStaff.some((s) => newShifts[s.id][d] === earlyPat.key);
      if (!hasEarly && earlyPat) {
        let cand = careStaff.filter((s) => {
          if (lockedSet.has(s.id)) return false;
          if (newShifts[s.id][d] !== '公休') return false;
          if (s.nightOnly) return false;
          if (!isStaffAvailable(s, year, month, d, earlyPat)) return false;
          if (getConsecutive(s, d) >= 5) return false;
          if (getMonthH(s) + earlyH > monthHLimit(s) + 0.1) return false;
          if (hasForbiddenConflict(s, d)) return false;
          return true;
        });

        if (cand.length === 0) {
          cand = careStaff.filter((s) => {
            if (lockedSet.has(s.id)) return false;
            if (newShifts[s.id][d] !== '公休') return false;
            if (s.nightOnly) return false;
            if (!isStaffAvailable(s, year, month, d, earlyPat)) return false;
            if (getConsecutive(s, d) >= 5) return false;
            if (hasForbiddenConflict(s, d)) return false;
            return true;
          });
        }

        if (cand.length > 0) {
          cand.sort((a, b) => (getMonthH(a) / monthHLimit(a)) - (getMonthH(b) / monthHLimit(b)));
          newShifts[cand[0].id][d] = earlyPat.key;
        }
      }

      // Late shift
      const hasLate = careStaff.some((s) => newShifts[s.id][d] === latePat.key);
      if (!hasLate && latePat && latePat.key !== earlyPat.key) {
        let cand = careStaff.filter((s) => {
          if (lockedSet.has(s.id)) return false;
          if (newShifts[s.id][d] !== '公休') return false;
          if (s.nightOnly) return false;
          if (!isStaffAvailable(s, year, month, d, latePat)) return false;
          if (getConsecutive(s, d) >= 5) return false;
          if (getMonthH(s) + lateH > monthHLimit(s) + 0.1) return false;
          if (hasForbiddenConflict(s, d)) return false;
          return true;
        });

        if (cand.length === 0) {
          cand = careStaff.filter((s) => {
            if (lockedSet.has(s.id)) return false;
            if (newShifts[s.id][d] !== '公休') return false;
            if (s.nightOnly) return false;
            if (!isStaffAvailable(s, year, month, d, latePat)) return false;
            if (getConsecutive(s, d) >= 5) return false;
            if (hasForbiddenConflict(s, d)) return false;
            return true;
          });
        }

        if (cand.length > 0) {
          cand.sort((a, b) => (getMonthH(a) / monthHLimit(a)) - (getMonthH(b) / monthHLimit(b)));
          newShifts[cand[0].id][d] = latePat.key;
        }
      }

      // Safety check: if no Late shift is on duty and night shift starts at 17:00, convert Early shift ('早' 07:00-16:00) to Day shift ('日' 09:00-18:00) if it's the only day shift staff member on duty, to seamlessly bridge 16:00-17:00!
      const workingCareOnDay = careStaff.filter((s) => isWorkShift(newShifts[s.id][d]));
      const hasLateOnDay = workingCareOnDay.some((s) => newShifts[s.id][d] === latePat.key);
      const hasStandardDay = workingCareOnDay.some((s) => newShifts[s.id][d] === stdDayPat.key);

      if (!hasLateOnDay && !hasStandardDay) {
        const earlyWorker = workingCareOnDay.find((s) => newShifts[s.id][d] === earlyPat.key);
        if (earlyWorker && isStaffAvailable(earlyWorker, year, month, d, stdDayPat)) {
          newShifts[earlyWorker.id][d] = stdDayPat.key;
        }
      }
    });

    // 5. Minimum Staffing Ratio Fulfillment: Ensure needed care ratio (e.g. 3 on duty) on every day
    // 重要: 管理者（管理職分）および計画作成担当者は介護職人員配置から控除（除外）して計算
    const neededRatio = getNeededStaff(fc);
    const ratioRoles = (fcType?.ratioRoles && fcType.ratioRoles.length > 0) ? fcType.ratioRoles : ['介護職員'];

    for (let d = 1; d <= days; d++) {
      if (fc.typeId === 'dayservice' && fc.bizDays && fc.bizDays.length > 0) {
        const dow = dayOfWeekIdx(year, month, d);
        if (!fc.bizDays.includes(dow)) continue;
      }

      // 当日の有効介護職員配置数（管理者業務分・計画作成業務分は厳密に控除）
      const calcCareOnDuty = () =>
        fcStaff.reduce((sum, s) => {
          const shiftKey = newShifts[s.id][d];
          if (isWorkShift(shiftKey) || shiftKey === '明け') {
            const careRatio = getStaffRoleAllocationRatio(s, ratioRoles);
            return sum + careRatio;
          }
          return sum;
        }, 0);

      let currentCareOnDuty = calcCareOnDuty();

      if (currentCareOnDuty < neededRatio - 0.001) {
        // 介護業務を担当可能な候補者のみを抽出（専従管理者・専従計画作成担当者は careRatio=0 のため除外）
        let cand = fcStaff.filter((s) => {
          if (lockedSet.has(s.id)) return false;
          if (newShifts[s.id][d] !== '公休') return false;
          if (s.nightOnly) return false;
          // 介護職員としての配分が0より大きい職員のみ
          if (getStaffRoleAllocationRatio(s, ratioRoles) <= 0) return false;
          if (!isStaffAvailable(s, year, month, d, stdDayPat)) return false;
          if (getConsecutive(s, d) >= 5) return false;
          if (getMonthH(s) + stdDayH > monthHLimit(s) + 0.1) return false;
          if (hasForbiddenConflict(s, d)) return false;
          return true;
        });

        // 労働時間枠内での候補が足りない場合は、月間上限をわずかに緩和してでも法令基準（介護職配置）を優先
        if (cand.length === 0) {
          cand = fcStaff.filter((s) => {
            if (lockedSet.has(s.id)) return false;
            if (newShifts[s.id][d] !== '公休') return false;
            if (s.nightOnly) return false;
            if (getStaffRoleAllocationRatio(s, ratioRoles) <= 0) return false;
            if (!isStaffAvailable(s, year, month, d, stdDayPat)) return false;
            if (getConsecutive(s, d) >= 5) return false;
            if (hasForbiddenConflict(s, d)) return false;
            return true;
          });
        }

        cand.sort((a, b) => {
          const aRatio = getMonthH(a) / monthHLimit(a);
          const bRatio = getMonthH(b) / monthHLimit(b);
          return aRatio - bRatio;
        });

        for (const s of cand) {
          if (currentCareOnDuty >= neededRatio - 0.001) break;
          newShifts[s.id][d] = stdDayPat.key;
          currentCareOnDuty += getStaffRoleAllocationRatio(s, ratioRoles);
        }
      }
    }
  });

  return newShifts;
}
