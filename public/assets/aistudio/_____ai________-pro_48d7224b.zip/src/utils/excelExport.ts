import * as XLSX from 'xlsx';
import { AppState } from '../types';
import { daysInMonth, dayOfWeekName, getStaffDayNetH, calcFTE } from './shiftEngine';
import { computeStaffSummaries, runFacilityChecks } from './complianceEngine';

export function exportShiftCalendarToExcel(state: AppState): void {
  const { year, month, staff, shifts, facility, shiftPatterns, parsedRules } = state;
  const days = daysInMonth(year, month);
  const wb = XLSX.utils.book_new();

  // 1. シフト表シート
  const sheetData: (string | number)[][] = [];

  // Title
  sheetData.push([`介護シフト表 ${year}年${month}月度`]);
  sheetData.push([`【事業所】${facility.name} (定員: ${facility.users}名)`]);
  sheetData.push([]);

  // Table Header
  const headerRow: (string | number)[] = ['氏名', '職種', '雇用形態'];
  for (let d = 1; d <= days; d++) {
    headerRow.push(`${d} (${dayOfWeekName(year, month, d)})`);
  }
  headerRow.push('総実労働h', '週平均h', '常勤換算(FTE)');
  sheetData.push(headerRow);

  staff.forEach((s) => {
    const roles = (Array.isArray(s.roles) ? s.roles : [s.role]).join('・');
    const row: (string | number)[] = [s.name, roles, s.type];

    let totalH = 0;
    for (let d = 1; d <= days; d++) {
      const k = shifts[s.id]?.[d] || '公休';
      row.push(k.startsWith('time:') ? k.replace('time:', '') : k);
      totalH += getStaffDayNetH(s.id, d, k, s.facilityId, shiftPatterns, parsedRules);
    }

    const weeks = days / 7;
    const weekAvg = weeks > 0 ? (totalH / weeks).toFixed(1) : '0.0';
    const fte = calcFTE(totalH, days);
    row.push(Number(totalH.toFixed(1)), Number(weekAvg), Number(fte));
    sheetData.push(row);
  });

  sheetData.push([]);

  // Legend
  sheetData.push(['【シフト凡例】']);
  shiftPatterns.forEach((p) => {
    sheetData.push([p.key, p.name, `${p.start}〜${p.end}`]);
  });
  sheetData.push(['有', '有給休暇', '0h']);
  sheetData.push(['希', '希望休', '0h']);
  sheetData.push(['休', '公休', '0h']);
  sheetData.push(['明', '明け（夜勤翌日）', '0h']);

  const wsShifts = XLSX.utils.aoa_to_sheet(sheetData);
  XLSX.utils.book_append_sheet(wb, wsShifts, 'シフト表');

  // 2. 集計・コンプライアンスシート
  const summaries = computeStaffSummaries(state);
  const facilityChecks = runFacilityChecks(state);

  const summaryData: (string | number)[][] = [
    ['職員別 月間集計表', `${year}年${month}月`],
    [`事業所: ${facility.name}`],
    [],
    [
      '氏名',
      '職種',
      'スキル',
      '専従/兼務',
      '出勤日数',
      '有休取得',
      '夜勤回数',
      '最大連勤日数',
      '総実労働時間',
      '週平均時間',
      '常勤換算(FTE)',
      '36協定判定',
    ],
  ];

  summaries.forEach((sum) => {
    summaryData.push([
      sum.name,
      sum.role,
      `Lv.${sum.mat}`,
      sum.dedicated ? '専従' : '兼務',
      sum.workDays,
      sum.paidLeaveCount,
      sum.nightShiftCount,
      sum.maxConsecutive,
      Number(sum.totalNetHours.toFixed(1)),
      Number(sum.avgWeeklyHours.toFixed(1)),
      Number(sum.fte),
      sum.over36 ? '⚠️ 超過注意' : '✅ 適正',
    ]);
  });

  summaryData.push([]);
  summaryData.push(['【人員配置基準適合判定】']);
  summaryData.push(['※厚生労働省の指定基準に基づき、管理者（管理職業務分）および計画作成担当者の時間は介護職基準から除外（控除）して算定しています。']);
  facilityChecks.forEach((fc) => {
    summaryData.push([`■ ${fc.facilityName} (${fc.facilityType})`, fc.allPassed ? '✅ 全基準クリア' : '❌ 要確認']);
    fc.checks.forEach((c) => {
      summaryData.push(['', c.label, c.req, `実績: ${c.actual}`, c.passed ? '適合' : '不足']);
    });
  });

  const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(wb, wsSummary, '集計・法令チェック');

  XLSX.writeFile(wb, `介護シフト_${facility.name}_${year}年${month}月.xlsx`);
}
