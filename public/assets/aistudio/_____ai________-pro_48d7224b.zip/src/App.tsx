import React, { useState, useEffect } from 'react';
import { AppState } from './types';
import { getInitialDemoState, APP_VERSION } from './constants';
import { generateShifts } from './utils/shiftEngine';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';

// Tabs
import { DashboardTab } from './components/tabs/DashboardTab';
import { FacilitiesTab } from './components/tabs/FacilitiesTab';
import { StaffTab } from './components/tabs/StaffTab';
import { PatternsTab } from './components/tabs/PatternsTab';
import { MaturityTab } from './components/tabs/MaturityTab';
import { CompatTab } from './components/tabs/CompatTab';
import { PreferenceTab } from './components/tabs/PreferenceTab';
import { GenerateTab } from './components/tabs/GenerateTab';
import { CalendarTab } from './components/tabs/CalendarTab';
import { BalanceTab } from './components/tabs/BalanceTab';
import { CheckTab } from './components/tabs/CheckTab';
import { ConfigTab } from './components/tabs/ConfigTab';

import {
  LayoutDashboard,
  Building2,
  Users,
  Clock,
  Award,
  HeartHandshake,
  CalendarDays,
  Sparkles,
  CalendarRange,
  TrendingUp,
  ShieldCheck,
  Settings,
} from 'lucide-react';

const STORAGE_KEY = 'kaigo_shift_pro_state_v1';

export default function App() {
  const [state, setState] = useState<AppState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.version === APP_VERSION && parsed.facility && parsed.staff) {
          if (Object.keys(parsed.shifts || {}).length === 0) {
            parsed.shifts = generateShifts(parsed);
          }
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to load state from localStorage:', e);
    }
    const initial = getInitialDemoState();
    if (Object.keys(initial.shifts || {}).length === 0) {
      initial.shifts = generateShifts(initial);
    }
    return initial;
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Persist to localStorage whenever state changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('Failed to save state to localStorage:', e);
    }
  }, [state]);

  const updateState = (updater: (prev: AppState) => AppState) => {
    setState(updater);
  };

  const tabs = [
    { id: 'dashboard', label: 'ダッシュボード', icon: LayoutDashboard },
    { id: 'facilities', label: '事業所設定', icon: Building2 },
    { id: 'staff', label: '職員マスタ', icon: Users },
    { id: 'patterns', label: 'シフト設定', icon: Clock },
    { id: 'maturity', label: 'スキル', icon: Award },
    { id: 'compat', label: '相性', icon: HeartHandshake },
    { id: 'preference', label: '希望入力', icon: CalendarDays },
    { id: 'generate', label: 'AI生成', icon: Sparkles, highlight: true },
    { id: 'calendar', label: 'シフト表', icon: CalendarRange },
    { id: 'balance', label: 'バランス', icon: TrendingUp },
    { id: 'check', label: 'コンプライアンス', icon: ShieldCheck },
    { id: 'config', label: '設定', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col text-gray-900 font-sans selection:bg-blue-600 selection:text-white">
      {/* Header */}
      <header className="bg-gradient-to-r from-slate-900 via-blue-950 to-blue-900 text-white shadow-md sticky top-0 z-40 border-b border-blue-800">
        <div className="max-w-[1800px] mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="text-2xl p-1.5 rounded-xl bg-blue-600/30 border border-blue-400/30 shadow-xs">
              🏥
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-tight">
                  介護シフトAI自動作成システム Pro
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 shadow-2xs">
                  ✨ PWA {APP_VERSION}
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-md bg-blue-800/80 text-[11px] font-semibold text-blue-100 border border-blue-700">
                  {state.facility.name}
                </span>
              </div>
              <p className="text-[11px] text-blue-200/80 font-medium">
                労働基準法・36協定・介護保険人員配置基準チェック付き
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Global Month Selector */}
            <div className="flex items-center gap-1 bg-white/10 backdrop-blur-xs px-2.5 py-1 rounded-xl border border-white/20">
              <button
                onClick={() => {
                  updateState((prev) => {
                    let y = prev.year;
                    let m = prev.month - 1;
                    if (m < 1) {
                      m = 12;
                      y--;
                    }
                    return { ...prev, year: y, month: m };
                  });
                }}
                className="text-white/80 hover:text-white px-1 text-sm font-bold cursor-pointer"
              >
                ◀
              </button>
              <span className="px-1 text-xs font-black text-white">
                {state.year}年 {state.month}月
              </span>
              <button
                onClick={() => {
                  updateState((prev) => {
                    let y = prev.year;
                    let m = prev.month + 1;
                    if (m > 12) {
                      m = 1;
                      y++;
                    }
                    return { ...prev, year: y, month: m };
                  });
                }}
                className="text-white/80 hover:text-white px-1 text-sm font-bold cursor-pointer"
              >
                ▶
              </button>
            </div>

            {/* PWA Install Button */}
            <PWAInstallButton />
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="bg-white/95 backdrop-blur-md border-t border-b border-gray-200 text-gray-700 shadow-xs">
          <div className="max-w-[1800px] mx-auto px-4 flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                    isActive
                      ? tab.highlight
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'bg-blue-600 text-white shadow-xs'
                      : tab.highlight
                      ? 'text-purple-700 hover:bg-purple-50 font-black'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : tab.highlight ? 'text-purple-600' : 'text-gray-500'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-[1800px] w-full mx-auto px-4 py-6">
        {activeTab === 'dashboard' && (
          <DashboardTab state={state} onNavigateTab={setActiveTab} />
        )}
        {activeTab === 'facilities' && (
          <FacilitiesTab state={state} onUpdateState={updateState} />
        )}
        {activeTab === 'staff' && (
          <StaffTab state={state} onUpdateState={updateState} />
        )}
        {activeTab === 'patterns' && (
          <PatternsTab state={state} onUpdateState={updateState} />
        )}
        {activeTab === 'maturity' && (
          <MaturityTab state={state} onUpdateState={updateState} />
        )}
        {activeTab === 'compat' && (
          <CompatTab state={state} onUpdateState={updateState} />
        )}
        {activeTab === 'preference' && (
          <PreferenceTab state={state} onUpdateState={updateState} />
        )}
        {activeTab === 'generate' && (
          <GenerateTab
            state={state}
            onUpdateState={updateState}
            onNavigateTab={setActiveTab}
          />
        )}
        {activeTab === 'calendar' && (
          <CalendarTab
            state={state}
            onUpdateState={updateState}
            onNavigateTab={setActiveTab}
          />
        )}
        {activeTab === 'balance' && <BalanceTab state={state} />}
        {activeTab === 'check' && (
          <CheckTab state={state} onNavigateTab={setActiveTab} />
        )}
        {activeTab === 'config' && (
          <ConfigTab state={state} onUpdateState={updateState} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 bg-white py-4 text-center text-xs text-gray-500">
        <div className="max-w-[1800px] mx-auto px-4 flex flex-wrap items-center justify-between gap-2">
          <span>介護シフトAI自動作成システム Pro {APP_VERSION} &copy; 2026 — PWA Offline Supported</span>
          <span>労働基準法（34条休憩・36条協定）/ 介護保険法人員配置基準対応</span>
        </div>
      </footer>

      {/* Floating Offline Notification */}
      <OfflineIndicator />
    </div>
  );
}
