import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function createPng(width, height, isMaskable = false) {
  // Simple uncompressed / deflated RGBA PNG generator
  // Color palette: deep blue #1e3a8a (30, 58, 138), gradient to #2563eb (37, 99, 235)
  // With white calendar card and red cross in the middle
  const rowSize = width * 4 + 1;
  const rawData = Buffer.alloc(rowSize * height);

  const cx = width / 2;
  const cy = height / 2;
  const safeRadius = isMaskable ? width * 0.4 : width * 0.45;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter type 0 (None)
    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;

      // Background gradient
      const t = (x + y) / (width + height);
      let r = Math.round(15 * (1 - t) + 37 * t);
      let g = Math.round(23 * (1 - t) + 99 * t);
      let b = Math.round(42 * (1 - t) + 235 * t);
      let a = 255;

      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Card area
      const cardW = width * 0.65;
      const cardH = height * 0.65;
      const inCardX = Math.abs(dx) <= cardW / 2;
      const inCardY = Math.abs(dy) <= cardH / 2;

      if (inCardX && inCardY) {
        // Top banner of calendar
        if (dy < -cardH / 2 + cardH * 0.25) {
          r = 30; g = 64; b = 175; // blue header #1e40af
        } else {
          r = 255; g = 255; b = 255; // white body
          // Medical cross in center
          const crossThickness = width * 0.07;
          const crossLength = width * 0.22;
          const inV = Math.abs(dx) <= crossThickness / 2 && Math.abs(dy - cardH * 0.1) <= crossLength / 2;
          const inH = Math.abs(dx) <= crossLength / 2 && Math.abs(dy - cardH * 0.1) <= crossThickness / 2;
          if (inV || inH) {
            r = 220; g = 38; b = 38; // red #dc2626
          }
        }
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // bit depth
  ihdrData[9] = 6; // RGBA
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace

  function makeChunk(type, data) {
    const len = data.length;
    const buf = Buffer.alloc(12 + len);
    buf.writeUInt32BE(len, 0);
    buf.write(type, 4, 4, 'ascii');
    data.copy(buf, 8);
    const crc = crc32(buf.subarray(4, 8 + len));
    buf.writeUInt32BE(crc, 8 + len);
    return buf;
  }

  // Simple CRC32
  function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      c ^= buf[i];
      for (let j = 0; j < 8; j++) {
        c = (c >>> 1) ^ (-(c & 1) & 0xedb88320);
      }
    }
    return (c ^ 0xffffffff) >>> 0;
  }

  const compressed = zlib.deflateSync(rawData);
  const ihdrChunk = makeChunk('IHDR', ihdrData);
  const idatChunk = makeChunk('IDAT', compressed);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

const pubDir = path.resolve('public');
if (!fs.existsSync(pubDir)) {
  fs.mkdirSync(pubDir, { recursive: true });
}

fs.writeFileSync(path.join(pubDir, 'pwa-192x192.png'), createPng(192, 192, false));
fs.writeFileSync(path.join(pubDir, 'pwa-512x512.png'), createPng(512, 512, false));
fs.writeFileSync(path.join(pubDir, 'pwa-maskable-512x512.png'), createPng(512, 512, true));
fs.writeFileSync(path.join(pubDir, 'apple-touch-icon.png'), createPng(180, 180, false));
fs.writeFileSync(path.join(pubDir, 'favicon.ico'), createPng(32, 32, false));

console.log('PWA PNG Icons generated successfully!');
