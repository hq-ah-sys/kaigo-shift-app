import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize GoogleGenAI server-side with User-Agent header as required
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server. Please check the Secrets panel in AI Studio.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// API: Check AI Server Status
app.get('/api/ai/status', (_req, res) => {
  const hasKey = !!process.env.GEMINI_API_KEY;
  res.json({
    available: hasKey,
    model: 'gemini-3.5-flash',
  });
});

// API: Test Connection
app.post('/api/ai/test', async (_req, res) => {
  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: 'Ping: 接続テストです。「OK」とだけ返答してください。',
    });
    const text = response.text || '';
    res.json({
      success: true,
      model: 'gemini-3.5-flash',
      message: `Gemini API (gemini-3.5-flash) サーバー側接続成功！レスポンス: ${text.trim()}`,
    });
  } catch (err: any) {
    const errMsg = err?.message || String(err);
    const isPermissionOrBillingError =
      err?.status === 403 ||
      err?.status === 'PERMISSION_DENIED' ||
      errMsg.includes('403') ||
      errMsg.includes('PERMISSION_DENIED') ||
      errMsg.includes('free tier is not available') ||
      errMsg.includes('billing');

    if (isPermissionOrBillingError) {
      console.warn('Gemini API test notice: Project requires billing or upgraded API key in Settings > Secrets.');
      return res.status(200).json({
        success: false,
        needsBillingOrKey: true,
        message:
          'Gemini API（有料プラン枠）の課金設定または有効なAPIキーが必要です。AI Studioの「Settings > Secrets」パネルで課金が有効なAPIキーを設定してください。（※本アプリの内蔵ルールエンジン・法令監査はそのまま正常にご利用いただけます）',
      });
    }

    console.warn('Gemini API test notice:', errMsg);
    res.status(200).json({
      success: false,
      message: `接続テスト失敗: ${errMsg}`,
    });
  }
});

// API: Interpret natural language instructions into shift rules
app.post('/api/ai/interpret', async (req, res) => {
  const { instructionText, staffList } = req.body;
  if (!instructionText) {
    return res.status(400).json({ error: '指示文を入力してください' });
  }

  try {
    const ai = getGeminiClient();
    const staffNames = Array.isArray(staffList)
      ? staffList.map((s: any) => `${s.id}:${s.name}`).join(', ')
      : '';

    const prompt = `あなたは介護シフト管理システムのAIエンジンです。
以下の自然言語によるシフト個別指示を解析し、構造化されたルールJSONを出力してください。

【登録職員一覧 (ID:氏名)】
${staffNames}

【ユーザーの個別指示】
${instructionText}

【出力形式】
必ず以下のJSONフォーマットのみを返してください。markdownのコードブロック等は含めず、純粋なJSON文字列で返してください。
{
  "rules": [
    {
      "staffId": 1,
      "staffName": "木村 正男",
      "ruleType": "deduct_hours",
      "hours": 2,
      "maxDays": null,
      "dates": [10],
      "text": "指示の要約"
    }
  ],
  "summary": "AIによる解析要約"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const outputText = response.text || '{}';
    let parsed: any = {};
    try {
      parsed = JSON.parse(outputText);
    } catch {
      const match = outputText.match(/\{[\s\S]*\}/);
      if (match) parsed = JSON.parse(match[0]);
    }

    return res.json({
      rules: parsed.rules || [],
      summary: parsed.summary || '解析が完了しました',
    });
  } catch (err: any) {
    console.warn('Gemini interpret notice (using rule engine fallback):', err?.message || err);
    // Parse using pattern matching fallback
    const fallbackRules: any[] = [];
    const lines = (instructionText || '').split('\n').map((l: string) => l.trim()).filter(Boolean);
    lines.forEach((line: string, idx: number) => {
      const matched = Array.isArray(staffList)
        ? staffList.find((s: any) => line.includes(s.name))
        : null;
      const hoursMatch = line.match(/(\d+)\s*(?:時間|h).*(?:除いて|管理業務|実働|引いて|マイナス)/);
      const dateMatch = line.match(/(\d{1,2})\s*日/g);
      const dates = dateMatch ? dateMatch.map((dm: string) => parseInt(dm.replace('日', ''), 10)) : undefined;

      if (hoursMatch && matched) {
        fallbackRules.push({
          id: `rule-${Date.now()}-${idx}`,
          text: line,
          staffName: matched.name,
          staffId: matched.id,
          ruleType: 'deduct_hours',
          hours: parseInt(hoursMatch[1], 10),
          dates,
        });
      } else {
        fallbackRules.push({
          id: `rule-${Date.now()}-${idx}`,
          text: line,
          staffName: matched?.name,
          staffId: matched?.id,
          ruleType: 'deduct_hours',
          hours: 0,
        });
      }
    });

    return res.json({
      rules: fallbackRules,
      summary: '【解析完了】ルールエンジンにより個別指示を自動解析・適用しました。',
      fallback: true,
    });
  }
});

// API: Comprehensive Compliance & Labor Audit
app.post('/api/ai/audit', async (req, res) => {
  const { payload } = req.body;
  if (!payload) {
    return res.status(400).json({ error: 'シフト監査データが提供されていません' });
  }

  try {
    const ai = getGeminiClient();
    const prompt = `あなたは介護事業所向けの労務管理および介護保険法コンプライアンスの専門家AIです。
以下のシフト実績データを精査し、介護報酬人員基準・労働基準法・36協定の観点から包括的な監査レポートを作成してください。

【重要法令基準の徹底】
・管理者の管理職業務時間、および計画作成担当者の計画作成業務時間は、介護職員の人員配置基準（直接処遇職員・3:1比率・常勤換算）から厳密に控除（除外）して評価すること。
・兼務職員（例: 管理者4h/介護職4h、計画作成4h/介護職4h）は、介護職員として実働した時間（4h＝0.5人換算）のみを介護職人員配置基準に算定し、管理職分・計画作成分は介護職基準に算入しないこと。
・専従管理者や専従計画作成担当者は介護職として0人換算であること。

【シフトデータ】
${JSON.stringify(payload, null, 2)}

【レポート構成（日本語・丁寧なビジネス専門口調）】
1. **総合診断結果**（✅適合 / ⚠️注意 / ❌要改善）
2. **人員配置基準の充足状況**（管理者・計画作成分控除後の直接介護員配置状況とクリア状況）
3. **労働基準法・36協定・労務リスク**（週40時間超過、連続勤務、夜勤間隔、問題職員を明記）
4. **具体的なシフト調整推奨事項**（管理者へのアドバイス3〜4項目）`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
    });

    const report = response.text || 'AI診断レポートの生成に失敗しました。';
    return res.json({ report });
  } catch (err: any) {
    console.warn('Gemini audit notice (using compliance engine fallback):', err?.message || err);
    const failedChecks = (payload.facilityChecks || []).flatMap((f: any) =>
      (f.checks || []).filter((c: any) => !c.passed)
    );
    const over36Staff = (payload.staffSummaries || []).filter((s: any) => s.over36);
    const highConsecStaff = (payload.staffSummaries || []).filter((s: any) => s.maxConsecutive >= 6);

    let report = `### 📋 介護シフト・コンプライアンス自動診断結果 (${payload.month || ''})\n\n`;
    report += `**総合評価:** ${
      failedChecks.length === 0 && over36Staff.length === 0
        ? '✅ 概ね良好（法令・人員基準適合）'
        : '⚠️ 是正推奨（一部要確認事項あり）'
    }\n\n`;

    report += `#### 1. 人員配置基準チェック\n`;
    if (failedChecks.length === 0) {
      report += `- ${payload.facility?.name || '事業所'} において法令上の配置基準をすべてクリアしています。\n`;
    } else {
      failedChecks.forEach((c: any) => {
        report += `- ❌ **${c.label}**: 要件「${c.req}」に対し実績「${c.actual}」と未達です。\n`;
      });
    }

    report += `\n#### 2. 労働基準法・36協定・連続勤務\n`;
    if (over36Staff.length === 0) {
      report += `- 週40時間超過職員はいません。\n`;
    } else {
      over36Staff.forEach((s: any) => {
        report += `- ⚠️ **${s.name}**: 週平均実労働${s.avgWeeklyHours}h（法定週40h超過の恐れがあります）。\n`;
      });
    }

    if (highConsecStaff.length > 0) {
      highConsecStaff.forEach((s: any) => {
        report += `- ⚠️ **${s.name}**: 最大${s.maxConsecutive}連勤が設定されています。5連勤以下への分散を推奨します。\n`;
      });
    } else {
      report += `- 6連勤以上の過度な連続勤務はありません。\n`;
    }

    report += `\n#### 3. 改善アドバイス\n`;
    report += `1. 夜勤明けの翌日は原則公休とし、十分な休息時間を確保してください。\n`;
    report += `2. 週40時間を超える恐れのある非常勤・常勤職員の勤務シフトを再配分してください。\n`;
    report += `3. 有給休暇の計画的付与（年5日取得義務）を月次で順次進めてください。\n`;

    return res.json({ report, fallback: true });
  }
});

// Setup Vite middlewares in development, or serve dist in production
async function start() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server ready at http://0.0.0.0:${port}`);
  });
}

start();
